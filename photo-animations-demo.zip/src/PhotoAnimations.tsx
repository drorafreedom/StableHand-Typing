import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { ReactP5Wrapper } from 'react-p5-wrapper'

type Direction = 'static' | 'up' | 'down' | 'left' | 'right' | 'oscillateUpDown' | 'oscillateRightLeft' | 'circular'

type Settings = {
  direction: Direction
  speed: number           // px/frame baseline (also modulates osc/circle)
  zoom: number            // 1.0 = 100%
  overlayColor: string    // hex color
  overlayOpacity: number  // 0..1
  autoPlay: boolean       // slideshow
  slideSeconds: number    // seconds per slide
  fit: 'cover' | 'contain'
  angle: number           // radians
  urls: string[]
}

const DEFAULTS: Settings = {
  direction: 'static',
  speed: 1.25,
  zoom: 1.1,
  overlayColor: '#000000',
  overlayOpacity: 0.2,
  autoPlay: true,
  slideSeconds: 8,
  fit: 'cover',
  angle: 0,
  urls: []
}

const THUMB_W = 96, THUMB_H = 60
const OSC_RANGE = 120
const CIRCLE_RADIUS = 200

export default function PhotoAnimations() {
  const [settings, setSettings] = useState<Settings>({...DEFAULTS})
  const [running, setRunning] = useState(true)
  const [resetNonce, setResetNonce] = useState(0)
  const [idx, setIdx] = useState(0)

  // Seed URLs from public/bgphotos
  useEffect(() => {
    if (settings.urls.length > 0) return
    const base = (import.meta as any).env?.BASE_URL || '/'
    const urls = Array.from({length: 6}, (_, i) => `${base}bgphotos/${i+1}.png`)
    setSettings(s => ({ ...s, urls }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Slideshow timer
  useEffect(() => {
    if (!running || !settings.autoPlay || settings.urls.length < 2) return
    const ms = Math.max(1000, settings.slideSeconds * 1000)
    const t = setInterval(() => setIdx(i => (i + 1) % settings.urls.length), ms)
    return () => clearInterval(t)
  }, [running, settings.autoPlay, settings.slideSeconds, settings.urls.length])

  const start = () => setRunning(true)
  const stop  = () => setRunning(false)
  const reset = () => {
    setSettings(s => ({ ...DEFAULTS, urls: s.urls.length ? s.urls : [] }))
    setIdx(0)
    setResetNonce(n => n + 1)
    setRunning(false)
  }
  const prev = () => setIdx(i => (settings.urls.length ? (i - 1 + settings.urls.length) % settings.urls.length : 0))
  const next = () => setIdx(i => (settings.urls.length ? (i + 1) % settings.urls.length : 0))

  const sketch = useCallback((p5: any) => {
    type Props = { settings: Settings; idx: number; running: boolean; resetNonce: number }

    let cur: Settings = { ...DEFAULTS }
    let index = 0
    let isRunning = true
    let lastReset = -1
    let t = 0, offX = 0, offY = 0

    const cache = new Map<string, any>()
    const getImage = (url: string) => {
      const c = cache.get(url)
      if (c) return c
      const img = p5.loadImage(url, () => {}, () => {})
      cache.set(url, img)
      return img
    }

    p5.setup = () => {
      p5.createCanvas(p5.windowWidth, p5.windowHeight)
      p5.frameRate(60)
      p5.noStroke()
    }
    p5.windowResized = () => p5.resizeCanvas(p5.windowWidth, p5.windowHeight)

    p5.updateWithProps = (props: Props) => {
      if (props.settings) cur = props.settings
      if (typeof props.idx === 'number') index = props.idx
      if (typeof props.running === 'boolean') isRunning = props.running
      if (typeof props.resetNonce === 'number' && props.resetNonce !== lastReset) {
        t = 0; offX = 0; offY = 0; lastReset = props.resetNonce
      }
      const list = cur.urls || []
      if (list.length >= 2) {
        getImage(list[(index + 1) % list.length])
        getImage(list[(index - 1 + list.length) % list.length])
      }
    }

    const drawImageFit = (img: any) => {
      if (!img || !img.width || !img.height) return
      const w = p5.width, h = p5.height
      const cx = w / 2, cy = h / 2
      const aspect = img.width / img.height
      let dw = w, dh = h
      if (cur.fit === 'cover') {
        if (w / h > aspect) dh = w / aspect; else dw = h * aspect
      } else {
        if (w / h > aspect) dw = h * aspect; else dh = w / aspect
      }
      const s = Math.max(0.05, cur.zoom || 1)
      dw *= s; dh *= s

      p5.push()
      p5.translate(cx + offX, cy + offY)
      if (cur.angle) p5.rotate(cur.angle)
      p5.imageMode(p5.CENTER)
      p5.image(img, 0, 0, dw, dh)
      p5.pop()

      if (cur.overlayOpacity > 0) {
        const c = p5.color(cur.overlayColor || '#000')
        c.setAlpha(Math.round(255 * Math.max(0, Math.min(1, cur.overlayOpacity))))
        p5.fill(c); p5.rect(0, 0, w, h)
      }
    }

    const stepMotion = () => {
      const v = cur.speed
      switch (cur.direction) {
        case 'static': break
        case 'up':    offY -= v; break
        case 'down':  offY += v; break
        case 'left':  offX -= v; break
        case 'right': offX += v; break
        case 'oscillateUpDown':    offY = OSC_RANGE * p5.sin(t * 1.5 * Math.max(0.2, v * 0.2)); break
        case 'oscillateRightLeft': offX = OSC_RANGE * p5.sin(t * 1.5 * Math.max(0.2, v * 0.2)); break
        case 'circular': {
          const w = Math.max(0.05, v * 0.02)
          offX = CIRCLE_RADIUS * p5.cos(t * w)
          offY = CIRCLE_RADIUS * p5.sin(t * w)
        } break
      }
    }

    p5.draw = () => {
      p5.clear()
      p5.background(0)
      const list = cur.urls || []
      if (list.length) {
        const img = getImage(list[index % list.length])
        drawImageFit(img)
      }
      if (isRunning) { t += 1/60; stepMotion() }
    }
  }, [])

  const thumbs = useMemo(() => settings.urls.map((u, i) => ({ u, i })), [settings.urls])

  // Inline control panel (self-contained)
  const fmt = (n: number, d = 1) => (Number.isFinite(n) ? n.toFixed(d) : '0')

  return (
    <div>
      {/* Controls */}
      <div style={{ position: 'fixed', right: 16, top: 12, zIndex: 50, width: 300, background: 'rgba(255,255,255,0.9)', borderRadius: 12, padding: 12, boxShadow: '0 8px 24px rgba(0,0,0,0.15)' }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <button onClick={start} style={{ flex: 1, padding: '8px 0', borderRadius: 8, background: '#16a34a', color: '#fff', border: 'none' }}>Start</button>
          <button onClick={stop}  style={{ flex: 1, padding: '8px 0', borderRadius: 8, background: '#dc2626', color: '#fff', border: 'none' }}>Stop</button>
          <button onClick={reset} style={{ flex: 1, padding: '8px 0', borderRadius: 8, background: '#6b7280', color: '#fff', border: 'none' }}>Reset</button>
        </div>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
          <input type="checkbox" checked={settings.autoPlay} onChange={(e) => setSettings(s => ({ ...s, autoPlay: e.target.checked }))} />
          Autoplay slideshow
        </label>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Seconds per slide: {fmt(settings.slideSeconds, 0)}s</div>
          <input type="range" min={2} max={30} step={1} value={settings.slideSeconds} onChange={(e) => setSettings(s => ({ ...s, slideSeconds: Number(e.target.value) }))} style={{ width: '100%' }} />
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Direction</div>
          <select value={settings.direction} onChange={(e) => setSettings(s => ({ ...s, direction: e.target.value as Direction }))} style={{ width: '100%', padding: 8, borderRadius: 8 }}>
            <option value="static">Static</option>
            <option value="up">Up</option>
            <option value="down">Down</option>
            <option value="left">Left</option>
            <option value="right">Right</option>
            <option value="oscillateUpDown">Oscillate Up/Down</option>
            <option value="oscillateRightLeft">Oscillate Left/Right</option>
            <option value="circular">Circular</option>
          </select>
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Speed: {fmt(settings.speed, 1)} px/frame</div>
          <input type="range" min={0} max={10} step={0.1} value={settings.speed} onChange={(e) => setSettings(s => ({ ...s, speed: Number(e.target.value) }))} style={{ width: '100%' }} />
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Zoom: {fmt(settings.zoom, 2)}×</div>
          <input type="range" min={0.5} max={3} step={0.01} value={settings.zoom} onChange={(e) => setSettings(s => ({ ...s, zoom: Number(e.target.value) }))} style={{ width: '100%' }} />
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Overlay color</div>
          <input type="color" value={settings.overlayColor} onChange={(e) => setSettings(s => ({ ...s, overlayColor: e.target.value }))} style={{ width: '100%', height: 32 }} />
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Overlay opacity: {Math.round(settings.overlayOpacity * 100)}%</div>
          <input type="range" min={0} max={100} step={1} value={Math.round(settings.overlayOpacity * 100)} onChange={(e) => setSettings(s => ({ ...s, overlayOpacity: Number(e.target.value) / 100 }))} style={{ width: '100%' }} />
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Fit</div>
          <select value={settings.fit} onChange={(e) => setSettings(s => ({ ...s, fit: e.target.value as Settings['fit'] }))} style={{ width: '100%', padding: 8, borderRadius: 8 }}>
            <option value="cover">Cover</option>
            <option value="contain">Contain</option>
          </select>
        </div>

        <div style={{ marginTop: 8 }}>
          <div style={{ fontSize: 12, marginBottom: 4 }}>Angle: {Math.round((settings.angle * 180) / Math.PI)}°</div>
          <input type="range" min={-180} max={180} step={1} value={Math.round((settings.angle * 180) / Math.PI)} onChange={(e) => setSettings(s => ({ ...s, angle: (Number(e.target.value) * Math.PI) / 180 }))} style={{ width: '100%' }} />
        </div>
      </div>

      {/* Canvas behind everything */}
      <div style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }}>
        <ReactP5Wrapper sketch={sketch} settings={settings} idx={idx} running={running} resetNonce={resetNonce} />
      </div>

      {/* Thumbnails + prev/next */}
      {!!thumbs.length && (
        <div style={{ position: 'fixed', left: 16, right: 16, bottom: 16, zIndex: 40, background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(8px)', padding: 8, borderRadius: 12, boxShadow: '0 8px 24px rgba(0,0,0,0.15)', display: 'flex', alignItems: 'center', gap: 8, overflowX: 'auto' }}>
          <button onClick={prev} title="Previous" style={{ padding: '4px 8px', borderRadius: 8, border: '1px solid #ddd', background: '#f3f4f6' }}>◀</button>
          {thumbs.map(({u, i}) => (
            <button key={u + i} onClick={() => setIdx(i)} title={u} style={{ width: THUMB_W, height: THUMB_H, border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden', outline: i === idx ? '3px solid #3b82f6' : 'none' }}>
              {/* eslint-disable-next-line jsx-a11y/alt-text */}
              <img src={u} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </button>
          ))}
          <button onClick={next} title="Next" style={{ padding: '4px 8px', borderRadius: 8, border: '1px solid #ddd', background: '#f3f4f6' }}>▶</button>
          <div style={{ marginLeft: 'auto', fontSize: 12, padding: '4px 8px', border: '1px solid #e5e7eb', borderRadius: 8, background: 'rgba(255,255,255,0.7)' }}>
            {idx + 1} / {settings.urls.length || 0}
          </div>
        </div>
      )}
    </div>
  )
}
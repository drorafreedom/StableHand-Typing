import React from 'react'
import PhotoAnimations from './PhotoAnimations'

export default function App() {
  return (
    <div style={{ minHeight: '100%', position: 'relative' }}>
      <PhotoAnimations />
      <div style={{ position: 'relative', zIndex: 10, padding: '16px' }}>
        <h1 style={{ margin: 0 }}>Photo Animations Demo</h1>
        <p>Type here while the background animates. (Canvas sits behind this content.)</p>
        <textarea placeholder="Start typing..." style={{ width: '100%', maxWidth: 900, height: 160, padding: 12, fontSize: 16 }} />
      </div>
    </div>
  )
}